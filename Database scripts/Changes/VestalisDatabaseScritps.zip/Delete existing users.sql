use VESTALIS3
go

delete from VestalisUserApplication

delete from aspnet_Membership

delete from aspnet_Profile

delete from aspnet_UsersInRoles

delete from aspnet_Users
