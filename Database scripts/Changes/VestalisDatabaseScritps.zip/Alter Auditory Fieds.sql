Use VESTALIS3
go
-- Table ApprovalItem
alter table [dbo].[ApprovalItem]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[ApprovalItem]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table ApprovalItem has been modified successfully'
--Table BusinessApplication
alter table [dbo].[BusinessApplication]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[BusinessApplication]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table BusinessApplication has been modified successfully'
--Table Catalogue
alter table [dbo].[Catalogue]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[Catalogue]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table Catalogue has been modified successfully'
-- Table CatalogueValue
alter table [dbo].[CatalogueValue]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[CatalogueValue]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table CatalogueValue has been modified successfully'
-- Table Country
alter table [dbo].[Country]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[Country]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table Country has been modified successfully'
-- Table Document
alter table [dbo].[Document]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[Document]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table Document has been modified successfully'
-- Table FormDefinition
alter table [dbo].[FormDefinition]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[FormDefinition]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table FormDefinition has been modified successfully'
-- Table InspectionReport
alter table [dbo].[InspectionReport]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[InspectionReport]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table InspectionReport has been modified successfully'
-- Table InspectionReportItem
alter table [dbo].[InspectionReportItem]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[InspectionReportItem]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table InspectionReportItem has been modified successfully'
-- Table Picture
alter table [dbo].[Picture]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[Picture]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table Picture has been modified successfully'
-- Table ServiceOrder
alter table [dbo].[ServiceOrder]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[ServiceOrder]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table ServiceOrder has been modified successfully'
-- Table ValidationRole
alter table [dbo].[ValidationRole]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[ValidationRole]
alter column [ModificationBy] nvarchar(200) 
go
Print 'The table ValidationRole has been modified successfully'
--Table VestalisUserApplication
alter table [dbo].[VestalisUserApplication]
alter column [CreationBy] nvarchar(200) 
go
alter table [dbo].[VestalisUserApplication]
alter column [ModificationBy] nvarchar(200) 
Print 'The table VestalisUserApplication has been modified successfully'